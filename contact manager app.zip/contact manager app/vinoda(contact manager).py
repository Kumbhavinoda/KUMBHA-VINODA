class Contact:
    name = ""
    number = ""
    Gmail = " "
 
def addContact():
    print()
    contact = Contact()
    contact.name = input("Enter contact name : ")
    contact.number = input("Enter contact number : ")
    contact.Gmail = input("Enter contact gmail : ")
    contactList.append(contact)
    print("Contact added.")
    print()
     
def getMenuChoice():
    print("1. Add new contact")
    print("2. Print all contacts")
    print("3. Quit")
    return input("Please enter your choice (1-3): ")
 
def printContacts():
    print()
    print("Printing contacts...")
    for itm in contactList:
        print (itm.name + ", " + itm.number),
    print()
 
contactList = []
choice = getMenuChoice()
while choice != "3":
    if choice == "1":
        addContact()
    elif choice == "2":
        printContacts()
    choice = getMenuChoice()
print()
print("Goodbye.")